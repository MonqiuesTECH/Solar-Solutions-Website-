import { useEffect, useRef } from 'react'
import Lenis from 'lenis'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import Navigation from './sections/Navigation'
import Hero from './sections/Hero'
import TrustedBy from './sections/TrustedBy'
import Solutions from './sections/Solutions'
import Technology from './sections/Technology'
import Analytics from './sections/Analytics'
import Process from './sections/Process'
import Footer from './sections/Footer'
import ChatBot from './sections/ChatBot'

gsap.registerPlugin(ScrollTrigger)

export default function App() {
  const lenisRef = useRef<Lenis | null>(null)

  useEffect(() => {
    const lenis = new Lenis({
      lerp: 0.12,
      smoothWheel: true,
    })
    lenisRef.current = lenis

    lenis.on('scroll', ScrollTrigger.update)

    gsap.ticker.add((time) => {
      lenis.raf(time * 1000)
    })
    gsap.ticker.lagSmoothing(0)

    return () => {
      lenis.destroy()
      gsap.ticker.remove(lenis.raf as unknown as gsap.TickerCallback)
    }
  }, [])

  return (
    <div className="bg-[#111111] text-white min-h-screen">
      <Navigation />
      <Hero />
      <TrustedBy />
      <Solutions />
      <Technology />
      <Analytics />
      <Process />
      <Footer />
      <ChatBot />
    </div>
  )
}
