import { useEffect, useRef } from 'react'
import * as THREE from 'three'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

function lerp(a: number, b: number, t: number) {
  return a + (b - a) * t
}

function getShapePositions(text: string): Float32Array {
  const canvas = document.createElement('canvas')
  canvas.width = 512
  canvas.height = 512
  const ctx = canvas.getContext('2d')!
  ctx.fillStyle = 'white'
  ctx.font = 'bold 100px Inter, sans-serif'
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillText(text, 256, 256)

  const imageData = ctx.getImageData(0, 0, 512, 512)
  const pixels = imageData.data
  const positions: number[] = []

  for (let y = 0; y < 512; y += 4) {
    for (let x = 0; x < 512; x += 4) {
      const i = (y * 512 + x) * 4
      if (pixels[i + 3] > 128) {
        positions.push((x - 256) / 256, (256 - y) / 256, 0)
      }
    }
  }

  // Pad to 480 points
  while (positions.length < 480 * 3) {
    const idx = (Math.floor(Math.random() * (positions.length / 3))) * 3
    positions.push(positions[idx] + (Math.random() - 0.5) * 0.1)
    positions.push(positions[idx + 1] + (Math.random() - 0.5) * 0.1)
    positions.push((Math.random() - 0.5) * 0.2)
  }

  return new Float32Array(positions.slice(0, 480 * 3))
}

export default function Analytics() {
  const containerRef = useRef<HTMLDivElement>(null)
  const canvasContainerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const container = canvasContainerRef.current
    if (!container) return

    const scene = new THREE.Scene()
    scene.fog = new THREE.Fog(0x111111, 15, 30)

    const camera = new THREE.PerspectiveCamera(
      50,
      container.clientWidth / container.clientHeight,
      0.1,
      50
    )
    camera.position.set(0, 10, 13)

    const renderer = new THREE.WebGLRenderer({ antialias: true })
    renderer.setSize(container.clientWidth, container.clientHeight)
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5))
    renderer.shadowMap.enabled = true
    renderer.shadowMap.type = THREE.PCFSoftShadowMap
    renderer.toneMapping = THREE.ACESFilmicToneMapping
    renderer.toneMappingExposure = 1.2
    renderer.domElement.style.width = '100%'
    renderer.domElement.style.height = '100%'
    renderer.domElement.style.display = 'block'
    container.appendChild(renderer.domElement)

    // Lighting
    const ambLight = new THREE.AmbientLight(0xffffff, 0.1)
    const hemiLight = new THREE.HemisphereLight(0xffffff, 0x444444, 0.4)
    const dirLight = new THREE.DirectionalLight(0xffffff, 0.8)
    dirLight.position.set(0, 5, 5)
    const dirLight2 = new THREE.DirectionalLight(0xffaa33, 0.6)
    dirLight2.position.set(5, 0, 0)
    scene.add(ambLight, hemiLight, dirLight, dirLight2)

    // Glyphs
    const glyphCount = 160
    const geom = new THREE.BoxGeometry(1, 1, 1)
    const mat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      emissive: 0xffffff,
      emissiveIntensity: 0.5,
    })

    const words = ['EFFICIENCY', 'ANALYTICS']
    let currentWordIndex = 0
    let currentWord = words[0]
    let targetShape = getShapePositions(currentWord)

    const group = new THREE.Group()
    group.position.y = -1
    scene.add(group)

    const meshes: THREE.Mesh[] = []
    const glyphPositions: THREE.Vector3[] = []

    for (let i = 0; i < glyphCount; i++) {
      const mesh = new THREE.Mesh(geom, mat)
      mesh.position.set(
        (Math.random() - 0.5) * 8,
        (Math.random() - 0.5) * 4,
        (Math.random() - 0.5) * 4
      )
      mesh.scale.set(0.05, 0.05, 0.05)
      mesh.castShadow = true
      mesh.receiveShadow = true
      group.add(mesh)
      meshes.push(mesh)
      glyphPositions.push(mesh.position.clone())
    }

    // Energy orb
    const orb = new THREE.Mesh(
      new THREE.IcosahedronGeometry(0.2, 1),
      new THREE.MeshBasicMaterial({ color: 0xffaa00, transparent: true, opacity: 0.8 })
    )
    scene.add(orb)

    // Animation
    let time = 0
    let angle = 0
    const gap = 0.2
    let animationId: number

    const intervalId = setInterval(() => {
      currentWordIndex = (currentWordIndex + 1) % words.length
      currentWord = words[currentWordIndex]
      targetShape = getShapePositions(currentWord)
    }, 3000)

    const tick = () => {
      animationId = requestAnimationFrame(tick)
      angle += 0.025
      time += 0.02

      camera.position.x = Math.sin(angle) * 13
      camera.position.z = Math.cos(angle) * 13
      camera.position.y = 15 + Math.cos(time) * 2
      camera.lookAt(new THREE.Vector3(0, 0, 0))

      // Update glyph positions
      for (let i = 0; i < glyphCount; i++) {
        const mesh = meshes[i]
        const targetX = lerp(targetShape[i * 3] || 0, targetShape[(i * 3 + 3) % targetShape.length] || 0, 0.6)
        const targetY = lerp(targetShape[i * 3 + 1] || 0, targetShape[(i * 3 + 4) % targetShape.length] || 0, 0.6)
        const targetZ = lerp(targetShape[i * 3 + 2] || 0, targetShape[(i * 3 + 5) % targetShape.length] || 0, 0.6)

        mesh.position.x = lerp(mesh.position.x, targetX, 0.02)
        mesh.position.y = lerp(mesh.position.y, targetY + gap, 0.02)
        mesh.position.z = lerp(mesh.position.z, targetZ, 0.02)
        mesh.rotation.x = time + i / 10
        mesh.rotation.y = time + i / 10
      }

      // Orb animation
      orb.position.x = Math.cos(time * 2.0) * 2
      orb.position.y = Math.sin(time * 2.5) * 1.5
      orb.position.z = Math.sin(time * 1.8) * 2.5

      renderer.render(scene, camera)
    }
    tick()

    // Resize
    const onResize = () => {
      if (!container) return
      camera.aspect = container.clientWidth / container.clientHeight
      camera.updateProjectionMatrix()
      renderer.setSize(container.clientWidth, container.clientHeight)
    }
    window.addEventListener('resize', onResize)

    // Entrance animation
    gsap.fromTo(
      container,
      { opacity: 0 },
      {
        opacity: 1,
        duration: 1,
        scrollTrigger: {
          trigger: containerRef.current,
          start: 'top 80%',
        },
      }
    )

    return () => {
      cancelAnimationFrame(animationId)
      clearInterval(intervalId)
      renderer.dispose()
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement)
      }
      window.removeEventListener('resize', onResize)
    }
  }, [])

  return (
    <section
      ref={containerRef}
      id="analytics"
      className="relative bg-[#111111]"
      style={{ height: '150vh' }}
    >
      {/* Canvas Container - sticky */}
      <div
        ref={canvasContainerRef}
        className="sticky top-0 w-full h-screen"
        style={{ zIndex: 1 }}
      />

      {/* Overlay Text */}
      <div className="absolute top-[120px] left-6 md:left-20 z-10 max-w-[400px] pointer-events-none">
        <p className="text-[#FFD700] text-sm uppercase tracking-[0.1em] font-medium mb-4">
          Live Analytics
        </p>
        <h2 className="text-[clamp(2rem,4vw,5rem)] font-normal uppercase text-white leading-[0.95] tracking-[-0.02em] mb-4">
          Data in Motion
        </h2>
        <p className="text-lg text-white/70 leading-relaxed">
          Real-time performance metrics from every installation in our network. Watch as energy
          flows through the system, visualized as living, breathing data.
        </p>
      </div>
    </section>
  )
}
