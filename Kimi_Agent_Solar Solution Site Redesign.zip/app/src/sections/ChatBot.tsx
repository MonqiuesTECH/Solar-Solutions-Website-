import { useState, useRef, useEffect } from 'react'
import { MessageCircle, Send, Bot, User, Minimize2 } from 'lucide-react'

interface Message {
  id: string
  role: 'user' | 'assistant'
  content: string
  timestamp: Date
}

// ============================================
// AI CHAT BOT - API INTEGRATION GUIDE
// ============================================
// To connect a real AI API (OpenAI, Claude, etc.):
// 1. Replace the mock response in handleSend() with an actual fetch call
// 2. Add your API key to environment variables: VITE_OPENAI_API_KEY
// 3. Example implementation below in handleSend()
// ============================================

const QUICK_REPLIES = [
  'Solar for my home',
  'Commercial project',
  'Government inquiry',
  'Get a quote',
  'Financing options',
]

const WELCOME_MESSAGE: Message = {
  id: 'welcome',
  role: 'assistant',
  content: `Welcome to Solara Nexus! I'm your AI solar assistant. I can help you with:

\u2022 Residential solar installations
\u2022 Commercial & government projects
\u2022 Battery storage & EV charging
\u2022 Financing options (PPA, Full Purchase)
\u2022 Free quotes and consultations

How can I help you today?`,
  timestamp: new Date(),
}

export default function ChatBot() {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([WELCOME_MESSAGE])
  const [inputValue, setInputValue] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  // Focus input when chat opens
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 100)
    }
  }, [isOpen])

  const generateResponse = async (userMessage: string): Promise<string> => {
    // ============================================
    // REAL API INTEGRATION - Replace this section
    // ============================================
    // const apiKey = import.meta.env.VITE_OPENAI_API_KEY
    // const response = await fetch('https://api.openai.com/v1/chat/completions', {
    //   method: 'POST',
    //   headers: {
    //     'Content-Type': 'application/json',
    //     'Authorization': `Bearer ${apiKey}`,
    //   },
    //   body: JSON.stringify({
    //     model: 'gpt-4',
    //     messages: [
    //       { role: 'system', content: 'You are a helpful solar energy consultant for Solara Nexus...' },
    //       ...messages.map(m => ({ role: m.role, content: m.content })),
    //       { role: 'user', content: userMessage },
    //     ],
    //   }),
    // })
    // const data = await response.json()
    // return data.choices[0].message.content
    // ============================================

    // Mock responses for demonstration
    const lowerMsg = userMessage.toLowerCase()

    if (lowerMsg.includes('home') || lowerMsg.includes('residential') || lowerMsg.includes('house')) {
      return `Great question about residential solar! Here's what we offer:

\u2022 **Custom system design** based on your roof and energy needs
\u2022 **Panels**: High-efficiency monocrystalline with 25-year warranties
\u2022 **Average savings**: 60-80% on electricity bills
\u2022 **Installation time**: 1-3 days for most homes
\u2022 **Financing**: $0 down PPA or full purchase with tax credits

Would you like to schedule a free site assessment? We serve DC and Maryland.`
    }

    if (lowerMsg.includes('commercial') || lowerMsg.includes('business') || lowerMsg.includes('office')) {
      return `Our commercial solar solutions are designed for maximum ROI:

\u2022 **Systems from 50kW to multi-MW** scale
\u2022 **ROI typically 4-7 years** with accelerated depreciation
\u2022 **Power Purchase Agreements** with $0 upfront
\u2022 **Peak demand shaving** to reduce demand charges
\u2022 **LEED certification** support

We've installed systems for office complexes, retail centers, and industrial facilities. Would you like a commercial proposal?`
    }

    if (lowerMsg.includes('government') || lowerMsg.includes('federal') || lowerMsg.includes('municipal')) {
      return `Solara Nexus specializes in government solar projects:

\u2022 **GSA Schedule compliant** installations
\u2022 **Federal tax incentives** and REAP grants
\u2022 **Energy savings performance contracts**
\u2022 **Military-grade security** and reliability standards
\u2022 **Lifecycle cost analysis** and reporting

We've worked with federal agencies, military bases, and municipal governments across the DMV area. How can we support your facility?`
    }

    if (lowerMsg.includes('quote') || lowerMsg.includes('price') || lowerMsg.includes('cost')) {
      return `I'd be happy to help you get a quote! To provide an accurate estimate, I'll need:

\u2022 Your **average monthly electricity bill**
\u2022 **Property type** (home, business, government)
\u2022 **Location** (we serve DC and Maryland)
\u2022 **Roof condition** (if residential)

Or you can call us directly at **202-249-1112** or email **sales@solarsolutiondc.com** for an immediate consultation.

Would you like to provide those details now?`
    }

    if (lowerMsg.includes('battery') || lowerMsg.includes('storage') || lowerMsg.includes('ev') || lowerMsg.includes('charger')) {
      return `Our energy storage and EV solutions include:

\u2022 **Tesla Powerwall** and **Enphase IQ Battery** systems
\u2022 **Backup power** during outages
\u2022 **Time-of-use optimization** for maximum savings
\u2022 **EV charging stations** (Level 2 and DC Fast)
\u2022 **Vehicle-to-home** integration (select models)

Battery storage can increase your solar savings by an additional 20-30%. Interested in adding storage to your system?`
    }

    if (lowerMsg.includes('finance') || lowerMsg.includes('ppa') || lowerMsg.includes('loan') || lowerMsg.includes('payment')) {
      return `We offer flexible financing options:

**$0 Down PPA (Power Purchase Agreement):**
\u2022 No upfront cost
\u2022 Pay only for the energy you use
\u2022 20-25 year term
\u2022 We own and maintain the system

**Full Purchase:**
\u2022 Maximum long-term savings
\u2022 30% Federal Tax Credit
\u2022 SREC income
\u2022 Multiple loan options available

**Which option interests you most?**`
    }

    if (lowerMsg.includes('contact') || lowerMsg.includes('phone') || lowerMsg.includes('email') || lowerMsg.includes('call')) {
      return `You can reach us through:

\u2022 **Phone**: 202-249-1112
\u2022 **Email**: sales@solarsolutiondc.com
\u2022 **Address**: 4700 14th St NW, Washington, DC 20011
\u2022 **Hours**: Monday-Friday, 9am-5pm

Or just let me know what you need here and I'll make sure it gets to the right team!`
    }

    return `Thank you for your message! That's a great question about solar energy.

At Solara Nexus, we've been powering DC and Maryland since 2008 with over 8,000 installations and 150,000+ panels deployed. Whether you're a homeowner, business, or government agency, we have a solution for you.

Could you tell me more about your project? For example:
- Are you looking for residential, commercial, or government solar?
- What's your approximate monthly electricity bill?
- Are you interested in battery storage or EV charging as well?

This will help me provide more specific information for your needs.`
  }

  const handleSend = async (text: string = inputValue) => {
    if (!text.trim() || isLoading) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: text.trim(),
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInputValue('')
    setIsLoading(true)

    try {
      const response = await generateResponse(userMessage.content)
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response,
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, assistantMessage])
    } catch {
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: 'I apologize, but I encountered an error. Please try again or contact us directly at 202-249-1112.',
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  const handleQuickReply = (reply: string) => {
    handleSend(reply)
  }

  return (
    <>
      {/* Chat Toggle Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 z-50 w-14 h-14 bg-[#FFD700] text-[#111111] rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform duration-300 group"
          aria-label="Open chat"
        >
          <MessageCircle className="w-6 h-6 group-hover:hidden" />
          <span className="hidden group-hover:block text-xs font-bold">CHAT</span>
          {/* Pulse animation */}
          <span className="absolute inset-0 rounded-full bg-[#FFD700] animate-ping opacity-30" />
        </button>
      )}

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-6 right-6 z-50 w-[380px] max-w-[calc(100vw-2rem)] h-[560px] max-h-[calc(100vh-2rem)] bg-[#222222] border border-[rgba(255,255,255,0.15)] rounded-lg shadow-2xl flex flex-col overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between px-5 py-4 bg-[#111111] border-b border-[rgba(255,255,255,0.15)]">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-gradient-to-r from-[#FFD700] to-[#39FF14] flex items-center justify-center">
                <Bot className="w-4 h-4 text-[#111111]" />
              </div>
              <div>
                <h3 className="text-white text-sm font-medium">Solar Assistant</h3>
                <p className="text-[#39FF14] text-xs">Online</p>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-[#666666] hover:text-white transition-colors duration-300"
              aria-label="Close chat"
            >
              <Minimize2 className="w-4 h-4" />
            </button>
          </div>

          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-3 ${message.role === 'user' ? 'flex-row-reverse' : ''}`}
              >
                {/* Avatar */}
                <div
                  className={`flex-shrink-0 w-7 h-7 rounded-full flex items-center justify-center ${
                    message.role === 'assistant'
                      ? 'bg-gradient-to-r from-[#FFD700] to-[#39FF14]'
                      : 'bg-[#FFD700]/20'
                  }`}
                >
                  {message.role === 'assistant' ? (
                    <Bot className="w-3.5 h-3.5 text-[#111111]" />
                  ) : (
                    <User className="w-3.5 h-3.5 text-[#FFD700]" />
                  )}
                </div>

                {/* Message Bubble */}
                <div
                  className={`max-w-[80%] p-3 rounded-lg text-sm leading-relaxed whitespace-pre-line ${
                    message.role === 'assistant'
                      ? 'bg-[#111111] text-white/90'
                      : 'bg-[#FFD700] text-[#111111]'
                  }`}
                >
                  {message.content}
                </div>
              </div>
            ))}

            {/* Loading indicator */}
            {isLoading && (
              <div className="flex gap-3">
                <div className="flex-shrink-0 w-7 h-7 rounded-full bg-gradient-to-r from-[#FFD700] to-[#39FF14] flex items-center justify-center">
                  <Bot className="w-3.5 h-3.5 text-[#111111]" />
                </div>
                <div className="bg-[#111111] p-3 rounded-lg">
                  <div className="flex gap-1">
                    <span className="w-2 h-2 bg-[#FFD700] rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="w-2 h-2 bg-[#FFD700] rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="w-2 h-2 bg-[#FFD700] rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                </div>
              </div>
            )}

            {/* Quick Replies */}
            {!isLoading && messages.length === 1 && (
              <div className="flex flex-wrap gap-2 pt-2">
                {QUICK_REPLIES.map((reply) => (
                  <button
                    key={reply}
                    onClick={() => handleQuickReply(reply)}
                    className="px-3 py-1.5 bg-[#111111] border border-[rgba(255,255,255,0.15)] text-[#FFD700] text-xs rounded hover:border-[#FFD700] transition-colors duration-300"
                  >
                    {reply}
                  </button>
                ))}
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="px-4 py-3 bg-[#111111] border-t border-[rgba(255,255,255,0.15)]">
            <div className="flex items-center gap-2">
              <input
                ref={inputRef}
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask about solar..."
                className="flex-1 bg-[#222222] text-white text-sm px-4 py-2.5 rounded border border-[rgba(255,255,255,0.15)] focus:border-[#FFD700] focus:outline-none transition-colors duration-300 placeholder:text-[#666666]"
              />
              <button
                onClick={() => handleSend()}
                disabled={!inputValue.trim() || isLoading}
                className="w-10 h-10 bg-[#FFD700] text-[#111111] rounded flex items-center justify-center hover:bg-white disabled:opacity-30 disabled:cursor-not-allowed transition-all duration-300"
                aria-label="Send message"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
