import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

const serviceLinks = [
  'Residential',
  'Commercial',
  'Government',
  'Battery Storage',
  'EV Charging',
  'Maintenance',
]

const companyLinks = ['About Us', 'Careers', 'Press', 'Blog', 'Contact']

const socialLinks = [
  { name: 'Instagram', href: 'https://www.instagram.com/solarsolutiondcllc/' },
  { name: 'Facebook', href: 'https://www.facebook.com/solarsolutiondcllc' },
  { name: 'X', href: 'https://x.com/SolarSolutionDC' },
  { name: 'LinkedIn', href: 'https://www.linkedin.com/company/solar-solution-llc/' },
]

export default function Footer() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!sectionRef.current) return
    const elements = sectionRef.current.querySelectorAll('.animate-in')
    gsap.fromTo(
      elements,
      { opacity: 0, y: 40 },
      {
        opacity: 1,
        y: 0,
        duration: 0.8,
        stagger: 0.1,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 80%',
        },
      }
    )
  }, [])

  return (
    <footer ref={sectionRef} id="footer" className="bg-[#222222]">
      {/* CTA Area */}
      <div className="content-max pt-24 md:pt-32 pb-20 md:pb-24 border-b border-[rgba(255,255,255,0.15)] text-center">
        <h2 className="animate-in text-[clamp(2rem,4vw,5rem)] font-normal uppercase text-white leading-[0.95] tracking-[-0.02em]">
          Ready to harness the sun?
        </h2>
        <p className="animate-in mt-6 text-lg text-[#666666] max-w-[600px] mx-auto">
          Join thousands of homeowners and businesses already saving with clean solar energy.
        </p>
        <button
          className="animate-in mt-12 bg-[#FFD700] text-[#111111] px-12 py-5 rounded text-base font-medium uppercase tracking-wide hover:scale-[1.03] transition-transform duration-300"
          onClick={() => alert('Quote request form coming soon! Contact us at 202-249-1112')}
        >
          Start Your Project
        </button>
      </div>

      {/* Footer Grid */}
      <div className="content-max py-16 md:py-20">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-8">
          {/* Column 1 - Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-3 h-3 rounded-full bg-gradient-to-r from-[#FFD700] to-[#39FF14]" />
              <span className="text-[#FFD700] font-bold text-lg tracking-tight uppercase">
                Solara Nexus
              </span>
            </div>
            <p className="text-sm text-[#666666]">Intelligent solar energy solutions</p>
          </div>

          {/* Column 2 - Services */}
          <div>
            <h4 className="text-white text-sm font-medium uppercase tracking-wider mb-6">
              Services
            </h4>
            <ul className="space-y-3">
              {serviceLinks.map((link) => (
                <li key={link}>
                  <span className="text-[#666666] text-sm hover:text-[#FFD700] transition-colors duration-300 cursor-pointer">
                    {link}
                  </span>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3 - Company */}
          <div>
            <h4 className="text-white text-sm font-medium uppercase tracking-wider mb-6">
              Company
            </h4>
            <ul className="space-y-3">
              {companyLinks.map((link) => (
                <li key={link}>
                  <span className="text-[#666666] text-sm hover:text-[#FFD700] transition-colors duration-300 cursor-pointer">
                    {link}
                  </span>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 4 - Contact */}
          <div>
            <h4 className="text-white text-sm font-medium uppercase tracking-wider mb-6">
              Get In Touch
            </h4>
            <div className="space-y-3 text-sm">
              <p className="text-white">202-249-1112</p>
              <p>
                <a
                  href="mailto:sales@solarsolutiondc.com"
                  className="text-[#FFD700] hover:underline"
                >
                  sales@solarsolutiondc.com
                </a>
              </p>
              <p className="text-[#666666]">
                4700 14th St NW,
                <br />
                Washington, DC 20011
              </p>
              <div className="pt-2">
                <p className="text-[#666666] text-xs uppercase tracking-wider mb-2">Hours</p>
                <p className="text-white">Monday – Friday</p>
                <p className="text-[#666666]">9 am – 5 pm</p>
              </div>
              <div className="flex gap-4 pt-3">
                {socialLinks.map((social) => (
                  <a
                    key={social.name}
                    href={social.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#666666] hover:text-[#FFD700] transition-colors duration-300 text-xs uppercase"
                  >
                    {social.name}
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="content-max py-6 border-t border-[rgba(255,255,255,0.15)] flex flex-col sm:flex-row justify-between items-center gap-4">
        <p className="text-sm text-[#666666]">
          &copy; 2025 Solara Nexus. All rights reserved.
        </p>
        <div className="flex gap-6 text-sm text-[#666666]">
          <span className="hover:text-white transition-colors duration-300 cursor-pointer">
            Privacy Policy
          </span>
          <span className="hover:text-white transition-colors duration-300 cursor-pointer">
            Terms of Service
          </span>
          <span className="hover:text-white transition-colors duration-300 cursor-pointer">
            Cookie Settings
          </span>
        </div>
      </div>
    </footer>
  )
}
