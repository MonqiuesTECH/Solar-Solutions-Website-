import { useEffect, useRef } from 'react'
import * as THREE from 'three'
import gsap from 'gsap'
import { ChevronDown } from 'lucide-react'

export default function Hero() {
  const containerRef = useRef<HTMLDivElement>(null)
  const canvasContainerRef = useRef<HTMLDivElement>(null)
  const contentRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const container = canvasContainerRef.current
    if (!container) return

    // Scene setup
    const scene = new THREE.Scene()
    scene.fog = new THREE.FogExp2(0x000000, 0.02)

    const camera = new THREE.PerspectiveCamera(
      60,
      window.innerWidth / window.innerHeight,
      0.1,
      1000
    )
    camera.position.z = 3.0

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true })
    renderer.setSize(window.innerWidth, window.innerHeight)
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
    renderer.domElement.style.width = '100%'
    renderer.domElement.style.height = '100%'
    renderer.domElement.style.display = 'block'
    container.appendChild(renderer.domElement)

    const clock = new THREE.Clock()

    // Generate particle glow texture
    const glowCanvas = document.createElement('canvas')
    glowCanvas.width = 64
    glowCanvas.height = 64
    const glowCtx = glowCanvas.getContext('2d')!
    const glowGrad = glowCtx.createRadialGradient(32, 32, 0, 32, 32, 32)
    glowGrad.addColorStop(0, 'rgba(255,255,255,1)')
    glowGrad.addColorStop(1, 'rgba(0,0,0,0)')
    glowCtx.fillStyle = glowGrad
    glowCtx.fillRect(0, 0, 64, 64)
    const particleTexture = new THREE.CanvasTexture(glowCanvas)

    // Star Sphere vertex shader
    const starVertShader = `
      varying vec2 vUv;
      varying vec3 vNormal;
      void main() {
        vUv = uv;
        vNormal = normalize(normalMatrix * normal);
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `

    // Star Sphere fragment shader
    const starFragShader = `
      varying vec2 vUv;
      varying vec3 vNormal;
      uniform vec3 color;
      uniform float time;
      void main() {
        float intensity = pow(0.6 - dot(vNormal, vec3(0.0, 0.0, 1.0)), 2.0);
        float pulse = 0.9 + 0.1 * sin(time * 2.0);
        gl_FragColor = vec4(color * 1.5, 1.0) * intensity * pulse;
      }
    `

    // Corona vertex shader
    const coronaVertShader = `
      varying vec2 vUv;
      varying vec3 vPosition;
      void main() {
        vUv = uv;
        vPosition = position;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `

    // Corona fragment shader with FBM noise
    const coronaFragShader = `
      varying vec2 vUv;
      varying vec3 vPosition;
      uniform float time;
      uniform vec3 color;

      vec3 mod289v3(vec3 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
      vec2 mod289v2(vec2 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
      vec3 permute(vec3 x) { return mod289v3(((x*34.0)+1.0)*x); }

      float snoise(vec2 v) {
        const vec4 C = vec4(0.211324865405187, 0.366025403784439, -0.577350269189626, 0.024390243902439);
        vec2 i = floor(v + dot(v, C.yy));
        vec2 x0 = v - i + dot(i, C.xx);
        vec2 i1;
        i1 = (x0.x > x0.y) ? vec2(1.0, 0.0) : vec2(0.0, 1.0);
        vec4 x12 = x0.xyxy + C.xxzz;
        x12.xy -= i1;
        i = mod289v2(i);
        vec3 p = permute(permute(i.y + vec3(0.0, i1.y, 1.0)) + i.x + vec3(0.0, i1.x, 1.0));
        vec3 m = max(0.5 - vec3(dot(x0,x0), dot(x12.xy,x12.xy), dot(x12.zw,x12.zw)), 0.0);
        m = m*m;
        m = m*m;
        vec3 x = 2.0 * fract(p * C.www) - 1.0;
        vec3 h = abs(x) - 0.5;
        vec3 ox = floor(x + 0.5);
        vec3 a0 = x - ox;
        m *= 1.79284291400159 - 0.85373472095314 * (a0*a0 + h*h);
        vec3 g;
        g.x = a0.x * x0.x + h.x * x0.y;
        g.yz = a0.yz * x12.xz + h.yz * x12.yw;
        return 130.0 * dot(m, g);
      }

      float fbm(vec2 x) {
        float v = 0.0;
        float a = 0.5;
        vec2 shift = vec2(100.0);
        mat2 rot = mat2(cos(0.5), sin(0.5), -sin(0.5), cos(0.50));
        for(int i = 0; i < 5; ++i) {
          v += a * snoise(x);
          x = rot * x * 2.0 + shift;
          a *= 0.5;
        }
        return v;
      }

      void main() {
        vec2 uv = vPosition.xy;
        float dist = length(uv);
        float angle = atan(uv.y, uv.x);
        float t = time * 0.05;
        vec2 noiseInput = vec2(
          cos(angle + t * 0.5) * (0.5 + 0.2 * sin(t * 0.7)),
          sin(angle - t * 0.3) * (0.5 + 0.2 * cos(t * 0.4))
        ) + vec2(cos(t * 0.1), sin(t * 0.2)) * 0.3;
        float n = fbm(noiseInput * 2.0 + fbm(noiseInput * 1.0 + t));
        float flare = max(0.0, 1.0 - smoothstep(0.1, 0.8, dist));
        flare *= pow(0.5 + 0.5 * sin(angle * 6.0 + t + n * 6.28), 3.0);
        flare *= (0.5 + 0.5 * snoise(vec2(angle * 3.0, t)));
        float corona = max(0.0, 1.0 - smoothstep(0.05, 1.5, dist));
        corona *= pow(0.5 + 0.5 * sin(angle * 12.0 - t * 1.5 + n * 6.28), 2.0);
        corona *= (0.7 + 0.3 * n);
        float core = smoothstep(0.1, 0.0, dist);
        float colorMix = snoise(vec2(angle * 2.0, t * 0.2)) * 0.5 + 0.5;
        vec3 finalColor = mix(color, vec3(1.0, 0.9, 0.6), colorMix);
        finalColor = mix(finalColor, vec3(1.0, 0.95, 0.8), core);
        float alpha = max(flare * 0.8, corona * 0.6) + core * 1.0;
        gl_FragColor = vec4(finalColor, alpha);
      }
    `

    // Particle vertex shader
    const particleVertShader = `
      attribute float size;
      attribute vec3 customColor;
      varying vec3 vColor;
      uniform float time;
      void main() {
        vColor = customColor;
        vec3 transformed = position + vec3(
          sin(time + position.y) * 0.1,
          cos(time + position.x) * 0.1,
          sin(time * 0.5 + position.z) * 0.1
        );
        vec4 mvPosition = modelViewMatrix * vec4(transformed, 1.0);
        gl_PointSize = size * (300.0 / -mvPosition.z);
        gl_Position = projectionMatrix * mvPosition;
      }
    `

    // Particle fragment shader
    const particleFragShader = `
      varying vec3 vColor;
      uniform sampler2D pointTexture;
      uniform float time;
      void main() {
        vec4 texColor = texture2D(pointTexture, gl_PointCoord);
        float life = sin(time * 0.5 + vColor.r * 10.0) * 0.5 + 0.5;
        texColor.rgb *= vColor;
        texColor.a *= life;
        gl_FragColor = texColor;
      }
    `

    // Aurora vertex shader
    const auroraVertShader = `
      varying vec2 vUv;
      varying float vElevation;
      uniform float time;
      varying vec3 vPosition;
      void main() {
        vUv = uv;
        vPosition = position;
        float elevation = sin(position.x * 2.0 + time) * cos(position.y * 2.0 + time * 0.5) * 0.2;
        vec3 newPosition = position + normal * elevation;
        vElevation = elevation;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(newPosition, 1.0);
      }
    `

    // Aurora fragment shader
    const auroraFragShader = `
      varying vec2 vUv;
      varying float vElevation;
      uniform float time;
      void main() {
        vec3 color = mix(vec3(0.1, 0.5, 0.2), vec3(0.2, 1.0, 0.4), vElevation + 0.5);
        color += vec3(0.1, 0.3, 0.1) * sin(vUv.x * 10.0 + time);
        float alpha = 0.3 + 0.2 * sin(vUv.x * 5.0 + time);
        gl_FragColor = vec4(color, alpha);
      }
    `

    // Star Sphere
    const starGeometry = new THREE.SphereGeometry(0.3, 64, 64)
    const starMaterial = new THREE.ShaderMaterial({
      vertexShader: starVertShader,
      fragmentShader: starFragShader,
      uniforms: {
        time: { value: 0 },
        color: { value: new THREE.Color(1.0, 0.9, 0.6) },
      },
      transparent: true,
      blending: THREE.AdditiveBlending,
    })
    const star = new THREE.Mesh(starGeometry, starMaterial)
    scene.add(star)

    // Corona Plane
    const coronaGeometry = new THREE.PlaneGeometry(6, 6, 1, 1)
    const coronaMaterial = new THREE.ShaderMaterial({
      vertexShader: coronaVertShader,
      fragmentShader: coronaFragShader,
      uniforms: {
        time: { value: 0 },
        color: { value: new THREE.Color(0.8, 0.5, 0.2) },
      },
      transparent: true,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
    })
    const corona = new THREE.Mesh(coronaGeometry, coronaMaterial)
    scene.add(corona)

    // Particle Storm
    const particleCount = 5000
    const positions = new Float32Array(particleCount * 3)
    const colors = new Float32Array(particleCount * 3)
    const sizes = new Float32Array(particleCount)

    for (let i = 0; i < particleCount; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 15
      positions[i * 3 + 1] = (Math.random() - 0.5) * 15
      positions[i * 3 + 2] = (Math.random() - 0.5) * 15

      const baseColor = new THREE.Color(
        0.8 + Math.random() * 0.2,
        0.4 + Math.random() * 0.4,
        0.1 + Math.random() * 0.2
      )
      colors[i * 3] = baseColor.r
      colors[i * 3 + 1] = baseColor.g
      colors[i * 3 + 2] = baseColor.b

      sizes[i] = 0.5 + Math.random() * 1.5
    }

    const particleGeometry = new THREE.BufferGeometry()
    particleGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3))
    particleGeometry.setAttribute('customColor', new THREE.BufferAttribute(colors, 3))
    particleGeometry.setAttribute('size', new THREE.BufferAttribute(sizes, 1))

    const particleMaterial = new THREE.ShaderMaterial({
      vertexShader: particleVertShader,
      fragmentShader: particleFragShader,
      uniforms: {
        time: { value: 0 },
        pointTexture: { value: particleTexture },
      },
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    })
    const particles = new THREE.Points(particleGeometry, particleMaterial)
    scene.add(particles)

    // Auroral Band
    const auroraGeometry = new THREE.TorusGeometry(1.8, 0.4, 16, 100)
    const auroraMaterial = new THREE.ShaderMaterial({
      vertexShader: auroraVertShader,
      fragmentShader: auroraFragShader,
      uniforms: {
        time: { value: 0 },
      },
      transparent: true,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
    })
    const aurora = new THREE.Mesh(auroraGeometry, auroraMaterial)
    aurora.rotation.x = Math.PI / 1.8
    scene.add(aurora)

    // Mouse interaction
    let mouseX = 0
    let mouseY = 0
    const onMouseMove = (e: MouseEvent) => {
      mouseX = (e.clientX - window.innerWidth / 2) * 0.001
      mouseY = (e.clientY - window.innerHeight / 2) * 0.001
    }
    document.addEventListener('mousemove', onMouseMove)

    // Animation loop
    let animationId: number
    const animate = () => {
      animationId = requestAnimationFrame(animate)
      const elapsedTime = clock.getElapsedTime()

      starMaterial.uniforms.time.value = elapsedTime
      coronaMaterial.uniforms.time.value = elapsedTime
      particleMaterial.uniforms.time.value = elapsedTime
      auroraMaterial.uniforms.time.value = elapsedTime

      star.rotation.y = elapsedTime * 0.05
      corona.rotation.z = elapsedTime * 0.02
      particles.rotation.y = elapsedTime * 0.01

      camera.position.x += (mouseX - camera.position.x) * 0.05
      camera.position.y += (-mouseY - camera.position.y) * 0.05
      camera.lookAt(scene.position)

      renderer.render(scene, camera)
    }
    animate()

    // Resize handler
    const onResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight
      camera.updateProjectionMatrix()
      renderer.setSize(window.innerWidth, window.innerHeight)
    }
    window.addEventListener('resize', onResize)

    return () => {
      cancelAnimationFrame(animationId)
      renderer.dispose()
      container.removeChild(renderer.domElement)
      document.removeEventListener('mousemove', onMouseMove)
      window.removeEventListener('resize', onResize)
    }
  }, [])

  // Content entrance animation
  useEffect(() => {
    if (!contentRef.current) return
    const elements = contentRef.current.querySelectorAll('.animate-in')
    gsap.fromTo(
      elements,
      { opacity: 0, y: 60 },
      { opacity: 1, y: 0, duration: 1, ease: 'power3.out', stagger: 0.15, delay: 0.5 }
    )
  }, [])

  return (
    <section ref={containerRef} className="relative w-full h-screen overflow-hidden">
      {/* Three.js Canvas Container */}
      <div
        ref={canvasContainerRef}
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          zIndex: 1,
        }}
      />

      {/* Bottom gradient fade */}
      <div
        className="absolute bottom-0 left-0 right-0 h-[15%] z-[5]"
        style={{ background: 'linear-gradient(transparent, #111111)' }}
      />

      {/* Content Overlay */}
      <div
        ref={contentRef}
        className="absolute inset-0 z-10 flex items-center"
        style={{ pointerEvents: 'none' }}
      >
        <div className="content-max w-full" style={{ pointerEvents: 'auto' }}>
          <div className="max-w-[50%]">
            {/* Eyebrow */}
            <div className="animate-in flex items-center gap-3 mb-8 opacity-0">
              <div className="w-10 h-[1px] bg-[#FFD700]" />
              <span className="text-[#FFD700] text-sm font-medium uppercase tracking-[0.1em]">
                Solar Energy Solutions
              </span>
            </div>

            {/* Headline */}
            <h1 className="animate-in opacity-0">
              <span className="block text-[clamp(3rem,8vw,8.75rem)] font-bold uppercase leading-[0.9] tracking-[-0.02em] text-white">
                Powering
              </span>
              <span className="block text-[clamp(3rem,8vw,8.75rem)] font-bold uppercase leading-[0.9] tracking-[-0.02em] text-white">
                Tomorrow
              </span>
            </h1>

            {/* Subheadline */}
            <p className="animate-in opacity-0 mt-8 text-lg md:text-xl font-light text-white/80 max-w-[480px] leading-relaxed">
              Intelligent solar installations for homes, businesses, and government facilities.
              Clean energy engineered for maximum efficiency.
            </p>

            {/* CTA Group */}
            <div className="animate-in opacity-0 mt-12 flex flex-wrap gap-4">
              <a
                href="#footer"
                onClick={(e) => {
                  e.preventDefault()
                  document.querySelector('#footer')?.scrollIntoView({ behavior: 'smooth' })
                }}
                className="inline-flex items-center bg-[#FFD700] text-[#111111] px-9 py-4 rounded text-sm font-medium uppercase tracking-wide hover:bg-white transition-colors duration-300"
              >
                Request a Consultation
              </a>
              <a
                href="#solutions"
                onClick={(e) => {
                  e.preventDefault()
                  document.querySelector('#solutions')?.scrollIntoView({ behavior: 'smooth' })
                }}
                className="inline-flex items-center border border-white text-white px-9 py-4 rounded text-sm font-medium uppercase tracking-wide hover:bg-white hover:text-[#111111] transition-all duration-300"
              >
                View Our Projects
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-2 animate-bounce">
        <ChevronDown className="w-5 h-5 text-white/50" />
        <span className="text-xs uppercase tracking-[0.1em] text-white/50">Scroll</span>
      </div>
    </section>
  )
}
