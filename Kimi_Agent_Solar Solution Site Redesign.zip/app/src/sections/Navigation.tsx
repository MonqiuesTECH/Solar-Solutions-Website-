import { useEffect, useState, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

const navLinks = [
  { label: 'Solutions', href: '#solutions' },
  { label: 'Technology', href: '#technology' },
  { label: 'Analytics', href: '#analytics' },
  { label: 'Process', href: '#process' },
  { label: 'About', href: '#footer' },
]

export default function Navigation() {
  const [scrolled, setScrolled] = useState(false)
  const navRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > window.innerHeight * 0.8)
    }
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    if (!navRef.current) return
    gsap.fromTo(
      navRef.current,
      { y: -80, opacity: 0 },
      { y: 0, opacity: 1, duration: 0.8, ease: 'power3.out', delay: 0.2 }
    )
  }, [])

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault()
    const target = document.querySelector(href)
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' })
    }
  }

  return (
    <nav
      ref={navRef}
      className={`fixed top-0 left-0 right-0 z-50 h-20 flex items-center transition-all duration-500 ${
        scrolled
          ? 'bg-[#111111]/90 backdrop-blur-xl border-b border-[rgba(255,255,255,0.15)]'
          : 'bg-transparent'
      }`}
    >
      <div className="content-max w-full flex items-center justify-between">
        {/* Logo */}
        <a href="#" className="flex items-center gap-2 group">
          <div className="w-3 h-3 rounded-full bg-gradient-to-r from-[#FFD700] to-[#39FF14]" />
          <span className="text-[#FFD700] font-bold text-xl tracking-tight uppercase">
            Solara Nexus
          </span>
        </a>

        {/* Nav Links */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              onClick={(e) => handleNavClick(e, link.href)}
              className="relative text-white/80 hover:text-white text-sm uppercase tracking-wide transition-colors duration-300 group"
            >
              {link.label}
              <span className="absolute -bottom-1 left-0 w-full h-0.5 bg-[#FFD700] scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left" />
            </a>
          ))}
        </div>

        {/* CTA */}
        <a
          href="#footer"
          onClick={(e) => handleNavClick(e, '#footer')}
          className="bg-[#FFD700] text-[#111111] px-7 py-3 text-sm font-medium uppercase rounded hover:bg-white transition-colors duration-300"
        >
          Get a Quote
        </a>
      </div>
    </nav>
  )
}
