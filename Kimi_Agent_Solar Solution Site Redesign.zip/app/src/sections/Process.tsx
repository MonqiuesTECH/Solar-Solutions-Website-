import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

const steps = [
  {
    num: '01',
    title: 'Consultation & Design',
    description:
      'We analyze your energy needs, roof geometry, and sun exposure to design a custom system optimized for your specific situation.',
  },
  {
    num: '02',
    title: 'Engineering & Permits',
    description:
      'Our engineers handle all structural calculations, electrical diagrams, and permit applications with local authorities.',
  },
  {
    num: '03',
    title: 'Installation',
    description:
      'Certified technicians install your system with precision. Most residential projects complete in 1-3 days with minimal disruption.',
  },
  {
    num: '04',
    title: 'Activation & Monitoring',
    description:
      'We commission your system, connect it to the grid, and activate our 24/7 monitoring platform. You start saving immediately.',
  },
]

export default function Process() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!sectionRef.current) return

    const elements = sectionRef.current.querySelectorAll('.animate-in')
    gsap.fromTo(
      elements,
      { opacity: 0, y: 40 },
      {
        opacity: 1,
        y: 0,
        duration: 0.8,
        stagger: 0.1,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 80%',
        },
      }
    )

    const cards = sectionRef.current.querySelectorAll('.step-card')
    gsap.fromTo(
      cards,
      { opacity: 0, y: 60 },
      {
        opacity: 1,
        y: 0,
        duration: 0.8,
        stagger: 0.15,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 70%',
        },
      }
    )
  }, [])

  return (
    <section
      ref={sectionRef}
      id="process"
      className="bg-[#111111] section-padding"
    >
      <div className="content-max">
        {/* Header */}
        <div className="text-center mb-24">
          <p className="animate-in text-[#FFD700] text-sm uppercase tracking-[0.1em] font-medium mb-6">
            Our Process
          </p>
          <h2 className="animate-in text-[clamp(2.5rem,5vw,5rem)] font-normal uppercase text-white leading-[0.95] tracking-[-0.02em]">
            From Blueprint to Bright
          </h2>
        </div>

        {/* Steps Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-0">
          {steps.map((step, index) => (
            <div
              key={index}
              className="step-card group relative px-4 lg:px-8"
            >
              {/* Divider line between steps */}
              {index > 0 && (
                <div className="hidden lg:block absolute left-0 top-0 bottom-0 w-[1px] bg-[rgba(255,255,255,0.15)]" />
              )}

              {/* Step Number */}
              <div className="text-[72px] font-bold leading-none text-[#FFD700]/30 group-hover:text-[#FFD700] transition-colors duration-300 mb-6">
                {step.num}
              </div>

              {/* Title */}
              <h3 className="text-xl md:text-2xl font-normal text-white mb-4 relative">
                {step.title}
                <span className="absolute -bottom-1 left-0 w-full h-[2px] bg-[#FFD700] scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left" />
              </h3>

              {/* Description */}
              <p className="text-[#666666] text-base leading-relaxed">
                {step.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
