import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { Sun, Building2, BatteryCharging, Wrench, ArrowRight } from 'lucide-react'

gsap.registerPlugin(ScrollTrigger)

const services = [
  {
    icon: Sun,
    title: 'Residential Solar',
    description:
      'Custom-designed photovoltaic systems for single-family homes, townhouses, and multi-unit residences. From roof assessment to final grid connection, we handle every detail.',
  },
  {
    icon: Building2,
    title: 'Commercial & Government',
    description:
      'Large-scale solar deployments for office complexes, municipal buildings, schools, and federal facilities. Engineered for maximum ROI and compliance with all regulatory standards.',
  },
  {
    icon: BatteryCharging,
    title: 'Battery Storage & EV Charging',
    description:
      'Integrated energy storage systems and electric vehicle charging infrastructure. Store excess generation and power your fleet with clean, self-generated electricity.',
  },
  {
    icon: Wrench,
    title: 'Maintenance & Monitoring',
    description:
      '24/7 system monitoring, proactive maintenance, and rapid-response repair services. Our AI-powered analytics platform predicts issues before they impact generation.',
  },
]

export default function Solutions() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!sectionRef.current) return

    const leftCol = sectionRef.current.querySelector('.left-col')
    const cards = sectionRef.current.querySelectorAll('.service-card')

    gsap.fromTo(
      leftCol,
      { opacity: 0, x: -40 },
      {
        opacity: 1,
        x: 0,
        duration: 0.8,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 80%',
        },
      }
    )

    gsap.fromTo(
      cards,
      { opacity: 0, y: 40 },
      {
        opacity: 1,
        y: 0,
        duration: 0.8,
        stagger: 0.15,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 70%',
        },
      }
    )
  }, [])

  return (
    <section
      ref={sectionRef}
      id="solutions"
      className="bg-[#111111] section-padding"
    >
      <div className="content-max">
        <div className="flex flex-col lg:flex-row gap-16 lg:gap-20">
          {/* Left Column - Sticky */}
          <div className="left-col lg:w-[40%] lg:sticky lg:top-40 lg:self-start">
            <p className="text-[#39FF14] text-sm uppercase tracking-[0.1em] font-medium mb-6">
              What We Do
            </p>
            <h2 className="text-3xl md:text-[40px] font-light text-white leading-[1.1]">
              Complete solar solutions from consultation to activation
            </h2>
          </div>

          {/* Right Column - Service Cards */}
          <div className="lg:w-[60%] space-y-6">
            {services.map((service, index) => (
              <div
                key={index}
                className="service-card group bg-[#222222] border border-[rgba(255,255,255,0.15)] p-8 md:p-10 hover:border-[#FFD700] transition-all duration-400 cursor-default relative overflow-hidden"
              >
                {/* Left accent bar */}
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-[#FFD700] scale-y-0 group-hover:scale-y-100 transition-transform duration-400 origin-bottom" />

                <div className="flex items-start gap-6">
                  <div className="flex-shrink-0">
                    <service.icon className="w-8 h-8 text-[#FFD700]" strokeWidth={1.5} />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl md:text-2xl font-normal text-white mb-3">
                      {service.title}
                    </h3>
                    <p className="text-[#666666] text-base leading-relaxed mb-4">
                      {service.description}
                    </p>
                    <span className="inline-flex items-center gap-2 text-[#FFD700] text-sm font-medium group-hover:gap-3 transition-all duration-300">
                      Learn More <ArrowRight className="w-4 h-4" />
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
