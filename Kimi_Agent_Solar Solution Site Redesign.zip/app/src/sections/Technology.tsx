import { useEffect, useRef, useMemo } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { Hand } from 'lucide-react'

gsap.registerPlugin(ScrollTrigger)

const vertexShader = `
  varying vec2 vUv;
  varying float vDisplace;
  uniform float uTime;

  // Simplex 3D noise
  vec4 permute(vec4 x){return mod(((x*34.0)+1.0)*x, 289.0);}
  vec4 taylorInvSqrt(vec4 r){return 1.79284291400159 - 0.85373472095314 * r;}

  float snoise(vec3 v){
    const vec2 C = vec2(1.0/6.0, 1.0/3.0);
    const vec4 D = vec4(0.0, 0.5, 1.0, 2.0);
    vec3 i  = floor(v + dot(v, C.yyy));
    vec3 x0 = v - i + dot(i, C.xxx);
    vec3 g = step(x0.yzx, x0.xyz);
    vec3 l = 1.0 - g;
    vec3 i1 = min(g.xyz, l.zxy);
    vec3 i2 = max(g.xyz, l.zxy);
    vec3 x1 = x0 - i1 + C.xxx;
    vec3 x2 = x0 - i2 + C.yyy;
    vec3 x3 = x0 - D.yyy;
    i = mod(i, 289.0);
    vec4 p = permute(permute(permute(
              i.z + vec4(0.0, i1.z, i2.z, 1.0))
            + i.y + vec4(0.0, i1.y, i2.y, 1.0))
            + i.x + vec4(0.0, i1.x, i2.x, 1.0));
    float n_ = 1.0/7.0;
    vec3 ns = n_ * D.wyz - D.xzx;
    vec4 j = p - 49.0 * floor(p * ns.z * ns.z);
    vec4 x_ = floor(j * ns.z);
    vec4 y_ = floor(j - 7.0 * x_);
    vec4 x = x_ * ns.x + ns.yyyy;
    vec4 y = y_ * ns.x + ns.yyyy;
    vec4 h = 1.0 - abs(x) - abs(y);
    vec4 b0 = vec4(x.xy, y.xy);
    vec4 b1 = vec4(x.zw, y.zw);
    vec4 s0 = floor(b0)*2.0 + 1.0;
    vec4 s1 = floor(b1)*2.0 + 1.0;
    vec4 sh = -step(h, vec4(0.0));
    vec4 a0 = b0.xzyw + s0.xzyw*sh.xxyy;
    vec4 a1 = b1.xzyw + s1.xzyw*sh.zzww;
    vec3 p0 = vec3(a0.xy, h.x);
    vec3 p1 = vec3(a0.zw, h.y);
    vec3 p2 = vec3(a1.xy, h.z);
    vec3 p3 = vec3(a1.zw, h.w);
    vec4 norm = taylorInvSqrt(vec4(dot(p0,p0), dot(p1,p1), dot(p2,p2), dot(p3,p3)));
    p0 *= norm.x;
    p1 *= norm.y;
    p2 *= norm.z;
    p3 *= norm.w;
    vec4 m = max(0.6 - vec4(dot(x0,x0), dot(x1,x1), dot(x2,x2), dot(x3,x3)), 0.0);
    m = m * m;
    return 42.0 * dot(m*m, vec4(dot(p0,x0), dot(p1,x1), dot(p2,x2), dot(p3,x3)));
  }

  void main() {
    vUv = uv;
    float noise = snoise(vec3(position.x * 1.5, position.y * 1.5, position.z * 1.5 + uTime));
    vDisplace = noise;
    vec3 newPosition = position + normal * (0.15 + noise * 0.15);
    vec4 mvPosition = modelViewMatrix * vec4(newPosition, 1.0);
    gl_PointSize = 2.0;
    gl_Position = projectionMatrix * mvPosition;
  }
`

const fragmentShader = `
  varying vec2 vUv;
  varying float vDisplace;
  uniform vec3 uColors[5];

  vec3 hue2rgb(float f1, float f2, float hue) {
    hue = mod(hue + 1.0, 1.0);
    if (6.0 * hue < 1.0) return f1 + (f2 - f1) * 6.0 * hue;
    if (2.0 * hue < 1.0) return f2;
    if (3.0 * hue < 2.0) return f1 + (f2 - f1) * ((2.0 / 3.0) - hue) * 6.0;
    return f1;
  }

  vec3 hsl2rgb(vec3 hsl) {
    if (hsl.y == 0.0) return vec3(hsl.z);
    float f2;
    if (hsl.z < 0.5)
      f2 = hsl.z * (1.0 + hsl.y);
    else
      f2 = hsl.z + hsl.y - hsl.y * hsl.z;
    float f1 = 2.0 * hsl.z - f2;
    return vec3(
      hue2rgb(f1, f2, hsl.x + 1.0/3.0),
      hue2rgb(f1, f2, hsl.x),
      hue2rgb(f1, f2, hsl.x - 1.0/3.0)
    );
  }

  void main() {
    vec3 hsl = vec3(0.28 + vDisplace * 0.15, 0.8, 0.6);
    vec3 rgb = hsl2rgb(hsl);
    float pattern = sin(vUv.x * 40.0 + vDisplace * 10.0) * 0.5 + 0.5;

    vec3 c = mix(uColors[1], uColors[3], smoothstep(0.0, 1.0, pattern));
    if (distance(pattern, uColors[0].x) < 0.02) c = uColors[4];
    if (distance(pattern, uColors[1].x) < 0.02) c = uColors[3];
    vec3 finalColor = c * (0.5 + 0.5 * sin(pattern * 6.28 + uColors[1].y));

    finalColor = mix(finalColor, vec3(1.0, 0.8, 0.0), smoothstep(0.4, 0.6, vDisplace));
    finalColor *= 0.8 + 0.2 * sin(vUv.y * 20.0 + 1.0);
    gl_FragColor = vec4(finalColor, 1.0);
  }
`

function EnergySphere() {
  const mesh = useRef<THREE.Mesh>(null)

  const uniforms = useMemo(
    () => ({
      uTime: { value: 0.0 },
      uColors: {
        value: [
          new THREE.Color('#39FF14'),
          new THREE.Color('#111111'),
          new THREE.Color('#222222'),
          new THREE.Color('#FFD700'),
          new THREE.Color('#FF9500'),
        ],
      },
    }),
    []
  )

  useFrame((state) => {
    if (!mesh.current) return
    const mat = mesh.current.material as THREE.ShaderMaterial
    mat.uniforms.uTime.value = state.clock.elapsedTime
    mesh.current.rotation.y = state.clock.elapsedTime * 0.05
    mesh.current.rotation.z = state.clock.elapsedTime * 0.05
    mesh.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.3) * 0.2
  })

  return (
    <mesh
      ref={mesh}
      position={[0, 0, 0]}
    >
      <icosahedronGeometry args={[1, 64]} />
      <shaderMaterial
        vertexShader={vertexShader}
        fragmentShader={fragmentShader}
        uniforms={uniforms}
        wireframe={false}
      />
    </mesh>
  )
}

const stats = [
  { value: '47.3 MW', label: 'Total Generation Capacity' },
  { value: '99.7%', label: 'System Uptime' },
  { value: '12,400+', label: 'Active Installations' },
  { value: '$2.1M', label: 'Client Savings This Year' },
]

export default function Technology() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!sectionRef.current) return
    const elements = sectionRef.current.querySelectorAll('.animate-in')
    gsap.fromTo(
      elements,
      { opacity: 0, y: 40 },
      {
        opacity: 1,
        y: 0,
        duration: 0.8,
        stagger: 0.1,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 80%',
        },
      }
    )
  }, [])

  return (
    <section
      ref={sectionRef}
      id="technology"
      className="bg-[#F5F5F5] section-padding"
    >
      <div className="content-max max-w-[1200px]">
        {/* Header */}
        <div className="text-center mb-20">
          <p className="animate-in text-sm uppercase tracking-[0.1em] text-[#666666] mb-6">
            Our Technology
          </p>
          <h2 className="animate-in text-[clamp(2.5rem,5vw,5rem)] font-normal uppercase text-[#111111] leading-[0.95] tracking-[-0.02em] mb-6">
            Feel the{' '}
            <span className="relative">
              <span className="text-[#39FF14]">Energy</span>
            </span>
          </h2>
          <p className="animate-in text-lg text-[#666666] max-w-[560px] mx-auto leading-relaxed">
            Our proprietary monitoring platform visualizes solar generation in real-time. Every
            panel, every watt, every moment — tracked and optimized.
          </p>
        </div>

        {/* Interactive Surface */}
        <div className="animate-in w-full h-[400px] md:h-[500px] bg-[#39FF14] rounded overflow-hidden cursor-grab active:cursor-grabbing relative">
          <Canvas
            dpr={Math.min(2, window.devicePixelRatio)}
            camera={{ position: [0, 0, 3.5], fov: 45 }}
            gl={{ antialias: true }}
          >
            <EnergySphere />
          </Canvas>
        </div>

        {/* Instruction */}
        <div className="animate-in flex items-center justify-center gap-2 mt-6 text-[#666666] text-sm">
          <Hand className="w-4 h-4" />
          <span>Click and drag to explore</span>
        </div>

        {/* Stats Bar */}
        <div className="animate-in grid grid-cols-2 md:grid-cols-4 gap-8 mt-16 pt-16 border-t border-[#111111]/10">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="text-[#111111] font-bold text-3xl md:text-5xl mb-2">
                {stat.value}
              </div>
              <div className="text-[#666666] text-xs md:text-sm uppercase tracking-wider">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
