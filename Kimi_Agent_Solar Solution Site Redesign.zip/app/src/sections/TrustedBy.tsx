import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

const partners = [
  ['NREL', 'Dept of Energy', 'SEIA', 'Tesla Energy', 'Enphase', 'SunPower'],
  ['LG Chem', 'SolarEdge', 'Fronius', 'IronRidge', 'Quick Mount PV', 'Unirac'],
]

export default function TrustedBy() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!sectionRef.current) return
    const items = sectionRef.current.querySelectorAll('.partner-item')
    gsap.fromTo(
      items,
      { opacity: 0, y: 30 },
      {
        opacity: 0.6,
        y: 0,
        duration: 0.6,
        stagger: 0.05,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 80%',
        },
      }
    )
  }, [])

  return (
    <section
      ref={sectionRef}
      className="bg-[#111111] py-20 border-t border-[rgba(255,255,255,0.15)]"
    >
      <div className="content-max">
        <p className="text-center text-sm uppercase tracking-[0.1em] text-[#666666] mb-12">
          Trusted by Leading Organizations
        </p>
        <div className="space-y-8">
          {partners.map((row, rowIdx) => (
            <div key={rowIdx} className="flex justify-center items-center gap-8 md:gap-16 flex-wrap">
              {row.map((name) => (
                <div
                  key={name}
                  className="partner-item opacity-60 hover:opacity-100 transition-all duration-400 hover:text-[#FFD700] cursor-default"
                >
                  <span className="text-white/60 hover:text-[#FFD700] text-sm md:text-base font-medium uppercase tracking-wider transition-colors duration-400">
                    {name}
                  </span>
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
